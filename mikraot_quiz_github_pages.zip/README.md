# משחק מקראות

זהו משחק HTML עצמאי המוכן לפרסום באמצעות GitHub Pages.

## העלאה ל-GitHub Pages

1. צור repository חדש ב-GitHub.
2. העלה אליו את הקובץ `index.html` שנמצא בתיקייה הזו.
3. ב-GitHub: Settings → Pages.
4. תחת Build and deployment בחר:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
5. שמור. GitHub יציג את כתובת האתר הציבורית.

המשחק עצמו אינו דורש שרת, ספריות חיצוניות או התקנה.
